package com.evernorth.components;

import org.springframework.stereotype.Component;

@Component
public class City {
	Integer id;
	String name;
	public City(){
		
	}
	public City(Integer id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	@Override
	public String toString() {
		return "City [id=" + id + ", name=" + name + "]";
	}
	

}
