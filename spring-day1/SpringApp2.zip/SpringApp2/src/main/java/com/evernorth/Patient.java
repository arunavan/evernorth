package com.evernorth;

public class Patient {
	 String name;

	public Patient(String name) {
		super();
		this.name = name;
	}

	@Override
	public String toString() {
		return "Patient [name=" + name + "]";
	}
	 
	 

}
