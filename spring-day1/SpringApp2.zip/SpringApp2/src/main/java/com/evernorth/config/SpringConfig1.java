package com.evernorth.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.evernorth.components")
public class SpringConfig1 {

}
