package com.evernorth.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.evernorth.Lab;

@Configuration
public class SpringConfig {
	
	@Bean
	public Lab lab() {
		return new Lab();
	}
	

}
