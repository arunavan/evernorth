package com.evernorth;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
       // Hospital h=new Hospital();
      //  System.out.println(h);
    	FileSystemXmlApplicationContext context = new 
FileSystemXmlApplicationContext("C:\\javaworkspace\\UST\\SpringApp2\\src\\main\\java\\com\\evernorth\\beans.xml");
        Hospital hospital1=(Hospital)context.getBean("h");
        System.out.println(hospital1+   "  "+hospital1.hashCode());
        Hospital hospital2=(Hospital)context.getBean("h");
        hospital2.setId(234);
        hospital2.setName("MEdinova");
        System.out.println(hospital2+"  "+hospital2.hashCode());
        
        Patient p1=(Patient)context.getBean("p");
        System.out.println(p1);
        context.close();
        
    }
}
