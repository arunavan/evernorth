package com.evernorth;

public class Lab {
	String type;
	public Lab() {
		type="UV";
	}

	public Lab(String type) {
		super();
		this.type = type;
	}

	@Override
	public String toString() {
		return "Lab [type=" + type + "]";
	}
	

}
