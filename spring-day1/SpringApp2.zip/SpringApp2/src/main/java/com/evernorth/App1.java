package com.evernorth;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.evernorth.components.City;
import com.evernorth.config.SpringConfig;
import com.evernorth.config.SpringConfig1;



public class App1 {
	
	public static void main(String[] args) {
		//  AnnotationConfigApplicationContext context = 
		//		  new AnnotationConfigApplicationContext(SpringConfig.class);
		  
		//  Lab l=(Lab)context.getBean(Lab.class);
	//	  System.out.println(l);
		  AnnotationConfigApplicationContext context1 = 
				  new AnnotationConfigApplicationContext(SpringConfig1.class);
		  
		  City c=(City)context1.getBean(City.class);
		  System.out.println(c);
	}

}
