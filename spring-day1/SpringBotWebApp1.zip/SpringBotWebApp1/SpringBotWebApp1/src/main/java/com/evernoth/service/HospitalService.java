package com.evernoth.service;

public class HospitalService {

}
