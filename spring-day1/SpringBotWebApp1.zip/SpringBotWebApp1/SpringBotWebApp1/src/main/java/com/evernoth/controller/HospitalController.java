package com.evernoth.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController //@Component
public class HospitalController {
	
	@GetMapping("/welcome")
	public String getMessage() {
		return "Welcome to Evernorth HEalthServices";
	}
	
	@GetMapping("/add")
	public String add() {
		return "adding ";
	}
	
	@GetMapping("/update")
	public String update() {
		return "updating";
	}
	@GetMapping("/list")
	public String displayall() {
		return "display all";
	}
	
	

}
