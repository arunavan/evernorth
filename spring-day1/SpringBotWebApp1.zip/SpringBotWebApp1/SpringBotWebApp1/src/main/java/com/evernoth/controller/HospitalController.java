package com.evernoth.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.evernoth.model.Hospital;
import com.evernoth.service.HospitalService;

@RestController //@Component
public class HospitalController {
	
	@Autowired
	HospitalService hospitalService;
	
	@GetMapping("/welcome")
	public String getMessage() {
		return "Welcome to Evernorth HEalthServices";
	}
	
	@GetMapping("/add")
	public String add() {
		Hospital h=new Hospital(102,"NIMS");
		hospitalService.addHospital(h);
		return "adding ";
	}
	
	@GetMapping("/update")
	public String update() {
		return "updating";
	}
	@GetMapping("/list")
	public String displayall() {
		hospitalService.listHospitals();
		return "display all";
	}
	
	@GetMapping("/listall")
	public List<Hospital> listAll(){
		return hospitalService.returnHospitals();
	}
	

}
