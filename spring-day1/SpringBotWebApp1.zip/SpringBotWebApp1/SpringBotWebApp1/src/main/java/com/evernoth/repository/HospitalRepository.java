package com.evernoth.repository;

public class HospitalRepository {

}
