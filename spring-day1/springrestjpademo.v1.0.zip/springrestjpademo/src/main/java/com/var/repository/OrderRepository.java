package com.var.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.var.entity.Order1;


@Repository
public interface OrderRepository  extends CrudRepository<Order1,Integer>{

}
