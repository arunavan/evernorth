package com.var;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringrestjpademoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringrestjpademoApplication.class, args);
	}

}

// application.properties
// springdoc.api-docs.path=/api-docs
// http://localhost:8082/api-docs
// http://localhost:8082/swagger-ui/index.html