package com.var.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.var.entity.Student;

@Repository
public interface StudentRepository extends CrudRepository<Student,Integer> {

}
