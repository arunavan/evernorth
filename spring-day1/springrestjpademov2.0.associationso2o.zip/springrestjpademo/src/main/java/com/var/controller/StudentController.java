package com.var.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.var.entity.Student;
import com.var.service.StudentService;
@RestController
public class StudentController {
	@Autowired
	StudentService studentService;
	@PostMapping("/student")
	public void addStudent(@RequestBody Student student) {
		studentService.addStudent(student);
	}
	@GetMapping("/student/{id}")
	public Student getStudent(@PathVariable("id") Integer id) {
		return studentService.getStudent(id);
	}
}
/*
 *
{
"studentId": 101,
"name": "ram",
"address": {
    "addressId": 1,
    "street": "tnagar",
    "city": "chennai",
    "state": "tamilnadu",
    "zipCode": "88888"
}
}


*/