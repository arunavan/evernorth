package com.var.entity;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="order1")
public class Order1 {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column
	Integer id;
	@Column
	Double amount;
	@Column
	LocalDate orderDate;
	public Order1(){}
	public Order1(Integer id, Double amount, LocalDate orderDate) {
		super();
		this.id = id;
		this.amount = amount;
		this.orderDate = orderDate;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public LocalDate getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}
	@Override
	public String toString() {
		return "Order [id=" + id + ", amount=" + amount + ", orderDate=" + orderDate + "]";
	}
	
	

}
