package com.var.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.var.entity.Student;
import com.var.repository.StudentRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class StudentService {
	
	@Autowired
	StudentRepository studentRepository;
	
	public void addStudent(Student student) {
		studentRepository.save(student);
	}
	
	public Student getStudent(Integer id) {
		return studentRepository.findById(id).get();
	}

}
