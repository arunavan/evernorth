package com.example.adpgateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdpGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
